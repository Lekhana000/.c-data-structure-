#include <stdio.h>
void names()
{
  printf("My name is sheethal");
  printf("Father's name:somesh\n");
  printf("Mother's name:sunitha\n");
}
void sheethal(){
  printf("my name;sheethal\n");
  printf("father's name:somesh\n");
}
int main(){
  names();
  sheethal();
  
}