#include <stdio.h>
void test()
{
  int n;
  scanf("%d",&n);
  
  if (n%2==0){
    printf("even");
  }
    else{
  printf("odd");
}}
  int main(){
    test();
  }
